flutter pub get
flutter build apk --release
pause
