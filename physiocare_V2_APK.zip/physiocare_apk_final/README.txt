# PhysioCare Therapist V2 - APK

## ما الجديد V2؟
- قسم البرامج العلاجية حسب نوع الحالة
- إرفاق صور وأشعة
- ملف التوثيق

## كيف تبني APK؟

### الطريقة 1: على كمبيوترك (5 دقائق)
1. حمل Flutter من flutter.dev
2. فك الضغط عن هذا الملف
3. افتح Terminal داخل المجلد:
   flutter pub get
   flutter build apk --release
4. APK موجود في:
   build/app/outputs/flutter-apk/app-release.apk
   انسخه لجوالك وثبته

### الطريقة 2: بدون كمبيوتر - موقع مجاني
1. ارفع هذا المشروع على github.com (انشئ حساب مجاني)
2. افتح codemagic.io وسجل بحساب GitHub
3. اختر المشروع > Build > Android > سيبني لك APK وتحمله

### الطريقة 3: PWA فوري (يثبت كتطبيق أصلي)
افتح النظام V2 في Chrome على جوالك > ثلاث نقاط > Add to Home Screen > سيثبت كأنه APK

## تفعيل التثبيت:
الاعدادات > الأمان > تثبيت من مصادر غير معروفة > سماح

## الربط بالنظام الرئيسي:
عدل ملف lib/screens/scanner_screen.dart:
String api = "https://your-center.com/api/checkin";
