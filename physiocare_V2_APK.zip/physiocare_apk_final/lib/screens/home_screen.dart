import 'package:flutter/material.dart';
import 'scanner_screen.dart';
import 'sessions_screen.dart';
import 'programs_screen.dart';
import 'session_detail_screen.dart';
class HomeScreen extends StatefulWidget{ @override _HomeScreenState createState()=>_HomeScreenState();}
class _HomeScreenState extends State<HomeScreen>{
  int idx=0;
  final screens=[Dashboard(), ScannerScreen(), SessionsScreen(), ProgramsScreen()];
  @override Widget build(BuildContext c){
    return Scaffold(
      body:screens[idx],
      bottomNavigationBar:NavigationBar(
        backgroundColor:Color(0xFF151E32),
        selectedIndex:idx,
        onDestinationSelected:(i)=>setState(()=>idx=i),
        destinations:[
          NavigationDestination(icon:Icon(Icons.dashboard_rounded),label:'الرئيسية'),
          NavigationDestination(icon:Icon(Icons.qr_code_scanner_rounded),label:'الماسح'),
          NavigationDestination(icon:Icon(Icons.medical_services_rounded),label:'البرامج'),
          NavigationDestination(icon:Icon(Icons.calendar_today_rounded),label:'جلساتي'),
        ],
      ),
    );
  }
}
class Dashboard extends StatelessWidget{
  @override Widget build(BuildContext c){
    return SafeArea(child:ListView(padding:EdgeInsets.all(20),children:[
      Row(children:[CircleAvatar(radius:24,backgroundColor:Color(0xFF5FB49C),child:Text('ع',style:TextStyle(color:Colors.white))),SizedBox(width:12),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('د. عبدالرحمن الخالدي',style:TextStyle(fontWeight:FontWeight.bold)),Text('أخصائي تأهيل',style:TextStyle(color:Colors.white60,fontSize:12))])]),
      SizedBox(height:20),
      Row(children:[_kpi('8','جلسات'),SizedBox(width:10),_kpi('2','برامج نشطة'),SizedBox(width:10),_kpi('5','مكتملة')]),
      SizedBox(height:20),
      Container(padding:EdgeInsets.all(16),decoration:BoxDecoration(color:Color(0xFF1E293B),borderRadius:BorderRadius.circular(20)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('ملف التوثيق - محمد أحمد',style:TextStyle(fontWeight:FontWeight.bold)),
        SizedBox(height:8),
        LinearProgressIndicator(value:0.75,color:Color(0xFF5FB49C),backgroundColor:Colors.white10),
        SizedBox(height:8),
        Text('التشخيص ✓  البرنامج ✓  الأشعة ✓  جلسة 1 ✓',style:TextStyle(fontSize:11,color:Colors.white60))
      ])),
      SizedBox(height:16),
      ElevatedButton.icon(onPressed:(){Navigator.push(c,MaterialPageRoute(builder:(_)=>SessionDetailScreen()));},icon:Icon(Icons.play_arrow_rounded),label:Text('بدء جلسة'),style:ElevatedButton.styleFrom(backgroundColor:Color(0xFF5FB49C),minimumSize:Size(double.infinity,52))),
    ]));
  }
  Widget _kpi(String n,String l){return Expanded(child:Container(padding:EdgeInsets.all(14),decoration:BoxDecoration(color:Color(0xFF1E293B),borderRadius:BorderRadius.circular(14)),child:Column(children:[Text(n,style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:Color(0xFF5FB49C))),Text(l,style:TextStyle(fontSize:10,color:Colors.white60))])));}
}
